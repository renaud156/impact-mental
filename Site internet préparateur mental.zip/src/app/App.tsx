import { useState, useCallback, useEffect } from 'react';
import { Brain, Target, Trophy, Users, Mail, Phone, MapPin, Menu, X, Eye, MessageCircle, Focus, Repeat, Heart, Zap, Award, TrendingUp, Check, Euro, Activity, Star, Quote, HelpCircle } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { Logo } from './components/Logo';
import { FAQ } from './components/FAQ';
import { BilanMental } from './components/BilanMental';
import { CtaBanner } from './components/CtaBanner';

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formStatus, setFormStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  const toggleMenu = useCallback(() => setMobileMenuOpen(prev => !prev), []);
  const closeMenu = useCallback(() => setMobileMenuOpen(false), []);

  const handleSubmit = useCallback(async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormStatus('sending');

    const form = e.currentTarget;
    const formData = new FormData(form);

    try {
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (data.success) {
        setFormStatus('success');
        form.reset();
        setTimeout(() => setFormStatus('idle'), 5000);
      } else {
        setFormStatus('error');
        setTimeout(() => setFormStatus('idle'), 5000);
      }
    } catch (error) {
      setFormStatus('error');
      setTimeout(() => setFormStatus('idle'), 5000);
    }
  }, []);

  // Gestion du smooth scroll avec offset pour le header fixe
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const link = target.closest('a[href^="#"]');

      if (link) {
        const href = link.getAttribute('href');
        if (href && href.startsWith('#')) {
          e.preventDefault();
          const elementId = href.substring(1);
          const element = document.getElementById(elementId);

          if (element) {
            const headerOffset = 80; // Hauteur du header fixe
            const elementPosition = element.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
              top: offsetPosition,
              behavior: 'smooth'
            });
          }
        }
      }
    };

    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Éléments décoratifs de fond */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl"></div>
      </div>

      <header className="fixed top-0 left-0 right-0 bg-background/80 backdrop-blur-md border-b border-border z-50">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo className="w-12 h-12" />
            <div>
              <span className="text-xl font-semibold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Impact Mental</span>
              <div className="text-xs text-muted-foreground">Préparation Mentale</div>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-6">
            <a href="#accueil" className="text-foreground hover:text-primary transition-colors">Accueil</a>
            <a href="#services" className="text-foreground hover:text-primary transition-colors">Services</a>
            <a href="#temoignages" className="text-foreground hover:text-primary transition-colors">Témoignages</a>
            <a href="#faq" className="text-foreground hover:text-primary transition-colors">FAQ</a>
            <a href="#questionnaire" className="text-foreground hover:text-primary transition-colors">Questionnaire</a>
            <a href="#tarifs" className="text-foreground hover:text-primary transition-colors">Tarifs</a>
            <a href="#contact" className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:opacity-90 transition-opacity">Contact</a>
          </div>

          <button
            className="lg:hidden p-2 hover:bg-primary/10 rounded-lg transition-colors"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6 text-primary" /> : <Menu className="w-6 h-6 text-primary" />}
          </button>
        </nav>

        {mobileMenuOpen && (
          <div className="lg:hidden bg-background/95 backdrop-blur-md border-t border-border">
            <div className="flex flex-col gap-3 px-4 py-6">
              <a href="#accueil" className="text-foreground hover:text-primary transition-colors py-2 px-4 hover:bg-primary/5 rounded-lg" onClick={closeMenu}>Accueil</a>
              <a href="#services" className="text-foreground hover:text-primary transition-colors py-2 px-4 hover:bg-primary/5 rounded-lg" onClick={closeMenu}>Services</a>
              <a href="#temoignages" className="text-foreground hover:text-primary transition-colors py-2 px-4 hover:bg-primary/5 rounded-lg" onClick={closeMenu}>Témoignages</a>
              <a href="#faq" className="text-foreground hover:text-primary transition-colors py-2 px-4 hover:bg-primary/5 rounded-lg" onClick={closeMenu}>FAQ</a>
              <a href="#questionnaire" className="text-foreground hover:text-primary transition-colors py-2 px-4 hover:bg-primary/5 rounded-lg" onClick={closeMenu}>Questionnaire</a>
              <a href="#tarifs" className="text-foreground hover:text-primary transition-colors py-2 px-4 hover:bg-primary/5 rounded-lg" onClick={closeMenu}>Tarifs</a>
              <a href="#contact" className="bg-gradient-to-r from-primary to-accent text-background px-6 py-3 rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all text-center font-medium mt-2" onClick={closeMenu}>Contact</a>
            </div>
          </div>
        )}
      </header>

      <main>
        <section id="accueil" className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
          {/* Grille de fond animée */}
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0" style={{
              backgroundImage: `linear-gradient(rgba(0, 212, 255, 0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 212, 255, 0.03) 1px, transparent 1px)`,
              backgroundSize: '50px 50px'
            }}></div>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1545809074-59472b3f5ecc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHx0ZW5uaXMlMjBwbGF5ZXIlMjBtZW50YWwlMjBmb2N1cyUyMGNvbmNlbnRyYXRpb258ZW58MXx8fHwxNzc5NDU4MDYyfDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Tennis player preparing mentally"
              className="w-full h-full object-cover opacity-10"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background"></div>
          </div>

          <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <div className="inline-block mb-6 px-6 py-2 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-medium">Coach Tennis depuis 2007 • Préparateur Mental depuis 2021</span>
              </div>

              <h1 className="text-5xl sm:text-6xl lg:text-8xl mb-6 font-bold">
                <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                  Impact Mental
                </span>
              </h1>

              <p className="text-xl sm:text-2xl text-foreground/80 mb-12 max-w-3xl mx-auto leading-relaxed">
                Préparation mentale spécialisée tennis et sports de performance.<br />
                <span className="text-primary">Développez votre mental</span> pour atteindre vos objectifs sportifs.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
                <a href="#contact" className="group relative bg-gradient-to-r from-primary to-accent text-background px-8 py-4 rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all text-lg font-medium overflow-hidden">
                  <span className="relative z-10">Réserver une séance</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-accent to-primary opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </a>
                <a href="#services" className="bg-card border-2 border-primary/30 text-foreground px-8 py-4 rounded-xl hover:border-primary hover:bg-primary/5 transition-all text-lg font-medium">
                  Découvrir mes services
                </a>
              </div>
            </div>

            {/* Indicateurs visuels */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="bg-card/50 backdrop-blur-sm border border-border rounded-2xl p-6 text-center hover:border-primary/50 transition-all">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Target className="w-6 h-6 text-background" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Performance</h3>
                <p className="text-sm text-muted-foreground">Optimisez vos résultats</p>
              </div>

              <div className="bg-card/50 backdrop-blur-sm border border-border rounded-2xl p-6 text-center hover:border-primary/50 transition-all">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-background" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Confiance</h3>
                <p className="text-sm text-muted-foreground">Renforcez votre mental</p>
              </div>

              <div className="bg-card/50 backdrop-blur-sm border border-border rounded-2xl p-6 text-center hover:border-primary/50 transition-all">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-6 h-6 text-background" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Progression</h3>
                <p className="text-sm text-muted-foreground">Atteignez vos objectifs</p>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="relative py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 text-slate-900 [&_.text-muted-foreground]:text-slate-600 [&_.text-foreground]:text-slate-900 [&_.border-border]:border-slate-200 [&_[class*='from-card']]:!from-white [&_[class*='to-card']]:!to-slate-50 [&_[class*='bg-card']]:!bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-medium">Services</span>
              </div>
              <h2 className="text-4xl sm:text-5xl mb-4 font-bold">
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Mes Services</span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Un accompagnement personnalisé pour développer votre force mentale et optimiser vos performances
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Target className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Préparation Mentale Tennis</h3>
                <p className="text-muted-foreground mb-4">
                  Spécialisation tennis : gestion du stress en compétition, concentration, confiance en soi, routines pré-match et gestion des points importants.
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Stratégies de match</li>
                  <li>• Gestion de la pression</li>
                  <li>• Visualisation positive</li>
                  <li>• Analyse post-match</li>
                </ul>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Trophy className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Sports Individuels</h3>
                <p className="text-muted-foreground mb-4">
                  Accompagnement des athlètes dans tous les sports individuels pour développer leur mental de compétiteur et atteindre leurs objectifs.
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Fixation d'objectifs</li>
                  <li>• Motivation intrinsèque</li>
                  <li>• Gestion de l'échec</li>
                  <li>• Préparation mentale pré-compétition</li>
                </ul>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Users className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Sports Collectifs</h3>
                <p className="text-muted-foreground mb-4">
                  Cohésion d'équipe, leadership, communication et gestion du collectif pour maximiser les performances de groupe.
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Cohésion d'équipe</li>
                  <li>• Leadership sportif</li>
                  <li>• Communication efficace</li>
                  <li>• Esprit collectif</li>
                </ul>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Brain className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Séances Individuelles</h3>
                <p className="text-muted-foreground mb-4">
                  Accompagnement personnalisé en présentiel ou en visio, adapté à vos besoins spécifiques et à votre calendrier sportif.
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Suivi personnalisé</li>
                  <li>• Flexibilité des horaires</li>
                  <li>• En présentiel ou visio</li>
                  <li>• Programme sur mesure</li>
                </ul>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Award className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Stages & Ateliers</h3>
                <p className="text-muted-foreground mb-4">
                  Stages intensifs et ateliers thématiques pour clubs, académies et structures sportives souhaitant intégrer la préparation mentale.
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Stages weekend</li>
                  <li>• Ateliers thématiques</li>
                  <li>• Formation de groupes</li>
                  <li>• Intervention en club</li>
                </ul>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Trophy className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Préparation Compétition</h3>
                <p className="text-muted-foreground mb-4">
                  Préparation intensive avant les échéances importantes : tournois, championnats, qualifications ou événements majeurs.
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Stratégie mentale</li>
                  <li>• Simulation de match</li>
                  <li>• Gestion du stress</li>
                  <li>• Optimisation performance</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* CTA après Services */}
        <CtaBanner
          title="Prêt à faire le point sur ton mental ?"
          description="Découvre tes forces et axes d'amélioration avec notre bilan mental gratuit en 10 minutes."
          primaryText="Faire mon bilan mental 🎯"
          primaryHref="#questionnaire"
        />

        <section id="questionnaire" className="relative py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 text-slate-900 [&_.text-muted-foreground]:text-slate-600 [&_.text-foreground]:text-slate-900 [&_.border-border]:border-slate-200 [&_[class*='from-card']]:!from-white [&_[class*='to-card']]:!to-slate-50 [&_[class*='bg-card']]:!bg-white">
          <BilanMental />
        </section>

        <section id="apropos" className="relative py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-medium">À propos</span>
              </div>
              <h2 className="text-4xl sm:text-5xl mb-4 font-bold">
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Renaud Olivier</span>
              </h2>
              <p className="text-xl text-muted-foreground">Votre partenaire en préparation mentale</p>
            </div>

            <div className="grid md:grid-cols-3 gap-12 items-start mb-16">
              {/* Photo professionnelle */}
              <div className="md:col-span-1">
                <div className="relative rounded-2xl overflow-hidden border-2 border-primary/30 hover:border-primary/50 transition-all group">
                  <div className="aspect-[3/4] bg-gradient-to-br from-primary/10 via-card to-accent/10 flex items-center justify-center">
                    {/* Placeholder pour photo professionnelle */}
                    <div className="text-center p-8">
                      <div className="w-24 h-24 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-4xl text-background font-bold">RO</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Photo professionnelle<br />à ajouter
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-2 gap-4">
                  <div className="bg-gradient-to-br from-card to-card/50 p-4 rounded-xl border border-primary/30 text-center">
                    <div className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">2007</div>
                    <div className="text-xs text-muted-foreground mt-1">Coach tennis</div>
                  </div>
                  <div className="bg-gradient-to-br from-card to-card/50 p-4 rounded-xl border border-primary/30 text-center">
                    <div className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">2021</div>
                    <div className="text-xs text-muted-foreground mt-1">Préparateur mental</div>
                  </div>
                </div>
              </div>

              {/* Contenu texte */}
              <div className="md:col-span-2 space-y-6">
                <div className="bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border">
                  <h3 className="text-2xl font-semibold mb-4 flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                      <Brain className="w-5 h-5 text-background" />
                    </div>
                    Mon Approche
                  </h3>
                  <div className="space-y-4 text-muted-foreground">
                    <p>
                      <strong className="text-foreground">Coach de tennis depuis 2007</strong> et <strong className="text-foreground">préparateur mental depuis 2021</strong>,
                      j'accompagne les athlètes dans le développement de leur force mentale pour atteindre leurs objectifs sportifs.
                    </p>
                    <p>
                      Mon approche combine des techniques éprouvées de <span className="text-primary">psychologie du sport</span>,
                      de <span className="text-primary">visualisation</span>, de <span className="text-primary">cohérence cardiaque</span> et
                      de développement de la confiance en soi.
                    </p>
                    <p>
                      Chaque programme est <strong className="text-foreground">100% personnalisé</strong> selon vos besoins,
                      votre niveau et vos objectifs spécifiques.
                    </p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-gradient-to-br from-card to-card/50 p-6 rounded-2xl border border-border">
                    <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                      <Target className="w-5 h-5 text-primary" />
                      Pour qui ?
                    </h4>
                    <ul className="space-y-2 text-muted-foreground text-sm">
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>Joueurs de tennis (tous niveaux)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>Athlètes individuels</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>Équipes sportives</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>Amateurs & Professionnels</span>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-gradient-to-br from-card to-card/50 p-6 rounded-2xl border border-border">
                    <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-primary" />
                      Objectifs
                    </h4>
                    <ul className="space-y-2 text-muted-foreground text-sm">
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>Améliorer vos performances</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>Gérer le stress & la pression</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>Renforcer votre confiance</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>Développer votre autonomie</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="temoignages" className="relative py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-medium">Témoignages</span>
              </div>
              <h2 className="text-4xl sm:text-5xl mb-4 font-bold">
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  Ils me font confiance
                </span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Retours d'expérience de sportifs accompagnés
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {/* Témoignage 1 */}
              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>

                <Quote className="w-10 h-10 text-primary/20 mb-4" />

                <p className="text-muted-foreground mb-6 italic">
                  "Grâce à l'accompagnement de Renaud, j'ai appris à mieux gérer ma pression en match.
                  Les techniques de cohérence cardiaque m'aident énormément avant mes tournois.
                  Mes résultats se sont vraiment améliorés !"
                </p>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                    <span className="text-background font-semibold">ML</span>
                  </div>
                  <div>
                    <div className="font-semibold">Marie L.</div>
                    <div className="text-sm text-muted-foreground">Joueuse de tennis - 15/2</div>
                  </div>
                </div>
              </div>

              {/* Témoignage 2 */}
              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>

                <Quote className="w-10 h-10 text-primary/20 mb-4" />

                <p className="text-muted-foreground mb-6 italic">
                  "La préparation mentale m'a permis de franchir un cap.
                  Les visualisations et les routines pré-match font maintenant partie intégrante de ma préparation.
                  Je me sens beaucoup plus confiant sur le terrain."
                </p>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                    <span className="text-background font-semibold">TD</span>
                  </div>
                  <div>
                    <div className="font-semibold">Thomas D.</div>
                    <div className="text-sm text-muted-foreground">Footballeur amateur</div>
                  </div>
                </div>
              </div>

              {/* Témoignage 3 */}
              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>

                <Quote className="w-10 h-10 text-primary/20 mb-4" />

                <p className="text-muted-foreground mb-6 italic">
                  "Excellent accompagnement ! Les séances m'ont aidé à mieux gérer mon stress avant les compétitions.
                  Renaud est à l'écoute et propose des outils concrets et efficaces.
                  Je recommande vivement."
                </p>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                    <span className="text-background font-semibold">SC</span>
                  </div>
                  <div>
                    <div className="font-semibold">Sophie C.</div>
                    <div className="text-sm text-muted-foreground">Athlète - Trail running</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 text-center">
              <p className="text-muted-foreground mb-6">Vous souhaitez partager votre expérience ?</p>
              <a href="#contact" className="inline-block bg-card border-2 border-primary/30 text-foreground px-8 py-3 rounded-xl hover:border-primary hover:bg-primary/5 transition-all font-medium">
                Contactez-moi
              </a>
            </div>
          </div>
        </section>

        <section id="tarifs" className="relative py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 text-slate-900 [&_.text-muted-foreground]:text-slate-600 [&_.text-foreground]:text-slate-900 [&_.border-border]:border-slate-200 [&_[class*='from-card']]:!from-white [&_[class*='to-card']]:!to-slate-50 [&_[class*='bg-card']]:!bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-medium">Tarifs</span>
              </div>
              <h2 className="text-4xl sm:text-5xl mb-4 font-bold">
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Mes Tarifs</span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Des formules adaptées à vos besoins et vos objectifs
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {/* Séance individuelle */}
              <div className="group bg-white p-8 rounded-2xl border-2 border-slate-200 hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-14 h-14 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Brain className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl font-semibold">Séance Individuelle</h3>
                </div>

                <div className="mb-6">
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">60€</span>
                    <span className="text-muted-foreground">/séance</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">1h en présentiel ou visio</p>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">Suivi personnalisé</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">Programme sur mesure</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">Outils pratiques</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">Flexibilité horaires</span>
                  </li>
                </ul>

                <a href="#contact" className="block w-full bg-slate-100 border-2 border-primary/30 text-slate-900 px-6 py-3 rounded-xl hover:border-primary hover:bg-primary/5 transition-all text-center font-medium">
                  Réserver
                </a>
              </div>

              {/* Forfait mensuel */}
              <div className="group relative bg-white p-8 rounded-2xl border-2 border-primary hover:border-accent hover:shadow-xl hover:shadow-primary/10 transition-all">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-primary to-accent px-4 py-1 rounded-full">
                  <span className="text-xs font-semibold text-white">POPULAIRE</span>
                </div>

                <div className="flex items-center gap-3 mb-6">
                  <div className="w-14 h-14 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Target className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl font-semibold">Forfait Mensuel</h3>
                </div>

                <div className="mb-6">
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">200€</span>
                    <span className="text-muted-foreground">/mois</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">4 séances d'1h (50€/séance)</p>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">4 séances par mois</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">Suivi régulier</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">Support par email</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">Économie de 40€</span>
                  </li>
                </ul>

                <a href="#contact" className="block w-full bg-gradient-to-r from-primary to-accent text-background px-6 py-3 rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all text-center font-medium">
                  Réserver
                </a>
              </div>
            </div>

            {/* Info complémentaire */}
            <div className="mt-12 max-w-3xl mx-auto">
              <div className="bg-white p-8 rounded-2xl border-2 border-slate-200">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center flex-shrink-0">
                    <Euro className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Informations pratiques</h4>
                    <ul className="space-y-2 text-muted-foreground">
                      <li>• Première séance découverte à tarif préférentiel</li>
                      <li>• Possibilité de forfaits personnalisés selon vos besoins</li>
                      <li>• Paiement par chèque, virement ou espèces</li>
                      <li>• Déplacements possibles en France (frais en sus)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="outils" className="relative py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-medium">Méthodologie</span>
              </div>
              <h2 className="text-4xl sm:text-5xl mb-4 font-bold">
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  Les Outils de la Préparation Mentale
                </span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Des techniques éprouvées pour développer votre mental de champion
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all">
                  <Activity className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Cohérence Cardiaque</h3>
                <p className="text-muted-foreground mb-4">
                  Technique de respiration rythmée pour réguler le stress, améliorer la concentration
                  et optimiser vos performances. Protocole simple de 3x5 minutes par jour.
                </p>
                <a href="#coherence" className="text-primary hover:text-accent transition-colors text-sm font-medium">
                  En savoir plus →
                </a>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all">
                  <Target className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Fixation d'Objectifs</h3>
                <p className="text-muted-foreground">
                  Définir des objectifs SMART (Spécifiques, Mesurables, Atteignables, Réalistes, Temporels)
                  pour maintenir votre motivation et structurer votre progression sportive avec clarté.
                </p>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all">
                  <Eye className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Visualisation Mentale</h3>
                <p className="text-muted-foreground">
                  Imaginer et répéter mentalement vos performances en détail (gestes, sensations, environnement)
                  pour améliorer votre exécution technique, renforcer votre confiance et préparer votre cerveau à la réussite.
                </p>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all">
                  <Heart className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Gestion du Stress</h3>
                <p className="text-muted-foreground">
                  Techniques de respiration profonde, relaxation musculaire progressive et ancrage sensoriel
                  pour contrôler votre stress, abaisser votre niveau d'anxiété et transformer la pression en énergie positive.
                </p>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all">
                  <Repeat className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Routines de Performance</h3>
                <p className="text-muted-foreground">
                  Créer des rituels pré-match (échauffement mental, gestes techniques) et entre les points
                  (respiration, focus) pour maintenir votre concentration, gérer vos émotions et assurer votre régularité.
                </p>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all">
                  <MessageCircle className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Discours Interne</h3>
                <p className="text-muted-foreground">
                  Développer un dialogue intérieur positif et constructif (auto-instructions, pensées motivantes)
                  pour renforcer votre confiance, contrer les pensées négatives et maintenir votre focus sur la tâche.
                </p>
              </div>

              <div className="group bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 transition-all">
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all">
                  <Focus className="w-8 h-8 text-background" />
                </div>
                <h3 className="text-2xl mb-4 font-semibold">Concentration</h3>
                <p className="text-muted-foreground">
                  Exercices d'attention sélective, de recentrage et de pleine conscience pour améliorer votre capacité
                  à rester focalisé sur le moment présent, éliminer les distractions et performer sous pression.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="coherence" className="relative py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-medium">Technique clé</span>
              </div>
              <h2 className="text-4xl sm:text-5xl mb-4 font-bold">
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  La Cohérence Cardiaque
                </span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Votre premier pas vers l'autonomie en préparation mentale
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h3 className="text-3xl font-semibold mb-6">Qu'est-ce que c'est ?</h3>
                <div className="space-y-4 text-muted-foreground text-lg">
                  <p>
                    La cohérence cardiaque est une <span className="text-primary font-medium">technique de respiration rythmée</span> qui
                    permet de réguler votre système nerveux autonome et d'atteindre un état d'équilibre physiologique et émotionnel optimal.
                  </p>
                  <p>
                    Grâce à son <span className="text-primary font-medium">excellent rapport simplicité/efficacité</span>, elle constitue
                    la porte d'entrée idéale pour débuter la préparation mentale et développer votre autonomie.
                  </p>
                  <p>
                    Cette pratique synchronise votre rythme cardiaque avec votre respiration, créant un état de
                    <span className="text-primary font-medium"> résonance cardiaque</span> aux multiples bienfaits.
                  </p>
                </div>
              </div>

              <div className="bg-gradient-to-br from-primary/10 via-card to-accent/10 p-8 rounded-2xl border-2 border-primary/30">
                <h4 className="text-2xl font-semibold mb-6 flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                    <Activity className="w-6 h-6 text-background" />
                  </div>
                  Protocole 3-6-5
                </h4>
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-primary font-bold">3</span>
                    </div>
                    <div>
                      <div className="font-semibold text-lg mb-1">3 fois par jour</div>
                      <p className="text-muted-foreground">Matin, midi et soir pour des effets optimaux</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-primary font-bold">6</span>
                    </div>
                    <div>
                      <div className="font-semibold text-lg mb-1">6 respirations par minute</div>
                      <p className="text-muted-foreground">5 secondes d'inspiration, 5 secondes d'expiration</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-primary font-bold">5</span>
                    </div>
                    <div>
                      <div className="font-semibold text-lg mb-1">5 minutes par session</div>
                      <p className="text-muted-foreground">Une pratique courte mais régulière</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mb-16">
              <h3 className="text-3xl font-semibold mb-8 text-center">Les Bienfaits</h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-gradient-to-br from-card to-card/50 p-6 rounded-2xl border border-border">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center mb-4">
                    <Brain className="w-6 h-6 text-background" />
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Concentration</h4>
                  <p className="text-muted-foreground text-sm">Amélioration de la clarté mentale et de la capacité d'attention</p>
                </div>

                <div className="bg-gradient-to-br from-card to-card/50 p-6 rounded-2xl border border-border">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center mb-4">
                    <Heart className="w-6 h-6 text-background" />
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Gestion du Stress</h4>
                  <p className="text-muted-foreground text-sm">Réduction de l'anxiété et meilleur contrôle émotionnel</p>
                </div>

                <div className="bg-gradient-to-br from-card to-card/50 p-6 rounded-2xl border border-border">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center mb-4">
                    <Users className="w-6 h-6 text-background" />
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Relations</h4>
                  <p className="text-muted-foreground text-sm">Amélioration des relations interpersonnelles et de la communication</p>
                </div>

                <div className="bg-gradient-to-br from-card to-card/50 p-6 rounded-2xl border border-border">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center mb-4">
                    <Trophy className="w-6 h-6 text-background" />
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Performance</h4>
                  <p className="text-muted-foreground text-sm">Optimisation de vos capacités physiques et mentales</p>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border">
                <h4 className="text-2xl font-semibold mb-4">Comment pratiquer ?</h4>
                <ol className="space-y-4 text-muted-foreground">
                  <li className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center text-primary font-semibold text-sm">1</span>
                    <span>Installez-vous confortablement, assis ou debout, le dos droit</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center text-primary font-semibold text-sm">2</span>
                    <span>Inspirez profondément par le nez pendant 5 secondes</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center text-primary font-semibold text-sm">3</span>
                    <span>Expirez lentement par la bouche pendant 5 secondes</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center text-primary font-semibold text-sm">4</span>
                    <span>Continuez ce rythme pendant 5 minutes</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center text-primary font-semibold text-sm">5</span>
                    <span>Pratiquez 3 fois par jour pour des résultats optimaux</span>
                  </li>
                </ol>
              </div>

              <div className="bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border">
                <h4 className="text-2xl font-semibold mb-4">Durée des effets</h4>
                <div className="space-y-4 text-muted-foreground">
                  <p className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                    <span><strong className="text-foreground">Immédiat :</strong> Effets ressentis dès la première session</span>
                  </p>
                  <p className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                    <span><strong className="text-foreground">Court terme :</strong> Bénéfices durant 4 à 6 heures après chaque session</span>
                  </p>
                  <p className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                    <span><strong className="text-foreground">Long terme :</strong> Amélioration durable avec une pratique régulière</span>
                  </p>
                </div>

                <div className="mt-6 p-4 bg-primary/10 rounded-xl border border-primary/20">
                  <p className="text-sm text-muted-foreground">
                    <span className="text-primary font-semibold">Conseil :</span> Combinez la cohérence cardiaque
                    avec des visualisations mentales pour maximiser la résonance cardiaque et décupler les effets.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-12 text-center">
              <div className="bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-primary/30 inline-block">
                <h4 className="text-2xl font-semibold mb-4">Intéressé par la cohérence cardiaque ?</h4>
                <p className="text-muted-foreground mb-6">
                  Apprenez à maîtriser cette technique lors d'une séance personnalisée
                </p>
                <a href="#contact" className="inline-block bg-gradient-to-r from-primary to-accent text-background px-8 py-4 rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all font-medium">
                  Réserver une séance
                </a>
              </div>
            </div>
          </div>
        </section>

        <section id="faq" className="relative py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 text-slate-900 [&_.text-muted-foreground]:text-slate-600 [&_.text-foreground]:text-slate-900 [&_.border-border]:border-slate-200 [&_[class*='from-card']]:!from-white [&_[class*='to-card']]:!to-slate-50 [&_[class*='bg-card']]:!bg-white">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-medium">Questions fréquentes</span>
              </div>
              <h2 className="text-4xl sm:text-5xl mb-4 font-bold">
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  FAQ
                </span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Les réponses à vos questions sur la préparation mentale
              </p>
            </div>

            <FAQ />

            <div className="mt-12 text-center">
              <div className="bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border inline-block">
                <HelpCircle className="w-12 h-12 text-primary mx-auto mb-4" />
                <h4 className="text-xl font-semibold mb-2">Vous avez d'autres questions ?</h4>
                <p className="text-muted-foreground mb-6">
                  N'hésitez pas à me contacter, je serai ravi d'y répondre
                </p>
                <a href="#contact" className="inline-block bg-gradient-to-r from-primary to-accent text-background px-6 py-3 rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all font-medium">
                  Me contacter
                </a>
              </div>
            </div>
          </div>
        </section>


        <section id="contact" className="relative py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-medium">Contact</span>
              </div>
              <h2 className="text-4xl sm:text-5xl mb-4 font-bold">
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Contactez-moi</span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Prêt à développer votre mental de champion ? Parlons de vos objectifs.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl mb-6">Informations de contact</h3>
                <div className="space-y-6">
                  <div className="flex items-start gap-4 group">
                    <div className="w-14 h-14 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <Mail className="w-6 h-6 text-background" />
                    </div>
                    <div>
                      <div className="font-medium mb-1">Email</div>
                      <a href="mailto:renaud_olivier@hotmail.fr" className="text-muted-foreground hover:text-primary transition-colors">
                        renaud_olivier@hotmail.fr
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 group">
                    <div className="w-14 h-14 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <Phone className="w-6 h-6 text-background" />
                    </div>
                    <div>
                      <div className="font-medium mb-1">Téléphone</div>
                      <a href="tel:+33665655605" className="text-muted-foreground hover:text-primary transition-colors">
                        06 65 65 56 05
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 group">
                    <div className="w-14 h-14 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <MapPin className="w-6 h-6 text-background" />
                    </div>
                    <div>
                      <div className="font-medium mb-1">Localisation</div>
                      <div className="text-muted-foreground">
                        Séances en présentiel et en visio<br />
                        Déplacements possibles en France
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-8 p-6 bg-gradient-to-br from-card to-card/50 rounded-2xl border border-border">
                  <h4 className="font-semibold mb-2 text-lg">Horaires de disponibilité</h4>
                  <p className="text-muted-foreground">
                    Lundi - Vendredi : 9h - 19h<br />
                    Samedi : 9h - 13h<br />
                    Dimanche : Sur rendez-vous
                  </p>
                </div>
              </div>

              <div className="bg-gradient-to-br from-card to-card/50 p-8 rounded-2xl border border-border">
                <form className="space-y-6" onSubmit={handleSubmit}>
                  {/* Champ caché pour Web3Forms - IMPORTANT: Remplacer YOUR_ACCESS_KEY par votre clé */}
                  <input type="hidden" name="access_key" value="YOUR_ACCESS_KEY_HERE" />
                  <input type="hidden" name="subject" value="Nouveau message depuis Impact Mental" />
                  <input type="hidden" name="from_name" value="Impact Mental - Site Web" />

                  <div>
                    <label htmlFor="name" className="block mb-2 font-medium">Nom complet</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      className="w-full px-4 py-3 bg-input-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                      placeholder="Votre nom"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block mb-2 font-medium">Email</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      className="w-full px-4 py-3 bg-input-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                      placeholder="votre@email.fr"
                    />
                  </div>

                  <div>
                    <label htmlFor="phone" className="block mb-2 font-medium">Téléphone</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      className="w-full px-4 py-3 bg-input-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                      placeholder="06 12 34 56 78"
                    />
                  </div>

                  <div>
                    <label htmlFor="sport" className="block mb-2 font-medium">Sport pratiqué</label>
                    <input
                      type="text"
                      id="sport"
                      name="sport"
                      className="w-full px-4 py-3 bg-input-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                      placeholder="Tennis, Football, etc."
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block mb-2 font-medium">Message</label>
                    <textarea
                      id="message"
                      name="message"
                      rows={4}
                      required
                      className="w-full px-4 py-3 bg-input-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none transition-all"
                      placeholder="Parlez-moi de vos objectifs..."
                    ></textarea>
                  </div>

                  {formStatus === 'success' && (
                    <div className="p-4 bg-green-500/10 border border-green-500/50 rounded-xl text-green-500">
                      ✓ Message envoyé avec succès ! Je vous répondrai rapidement.
                    </div>
                  )}

                  {formStatus === 'error' && (
                    <div className="p-4 bg-red-500/10 border border-red-500/50 rounded-xl text-red-500">
                      ✗ Une erreur est survenue. Veuillez réessayer ou m'envoyer un email directement.
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={formStatus === 'sending'}
                    className="w-full bg-gradient-to-r from-primary to-accent text-background px-8 py-4 rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {formStatus === 'sending' ? 'Envoi en cours...' : 'Envoyer le message'}
                  </button>

                  <p className="text-xs text-muted-foreground text-center">
                    En soumettant ce formulaire, vous acceptez d'être contacté par email ou téléphone.
                  </p>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="relative bg-gradient-to-b from-background to-card border-t border-border py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Logo className="w-10 h-10" />
                <div>
                  <span className="font-semibold text-lg bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Impact Mental</span>
                </div>
              </div>
              <p className="text-muted-foreground">
                Préparation mentale spécialisée tennis et sports de performance.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#services" className="hover:text-primary transition-colors">Tennis</a></li>
                <li><a href="#services" className="hover:text-primary transition-colors">Sports individuels</a></li>
                <li><a href="#services" className="hover:text-primary transition-colors">Sports collectifs</a></li>
                <li><a href="#services" className="hover:text-primary transition-colors">Stages</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Navigation</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#accueil" className="hover:text-primary transition-colors">Accueil</a></li>
                <li><a href="#services" className="hover:text-primary transition-colors">Services</a></li>
                <li><a href="#temoignages" className="hover:text-primary transition-colors">Témoignages</a></li>
                <li><a href="#faq" className="hover:text-primary transition-colors">FAQ</a></li>
                <li><a href="#questionnaire" className="hover:text-primary transition-colors">Questionnaire</a></li>
                <li><a href="#tarifs" className="hover:text-primary transition-colors">Tarifs</a></li>
                <li><a href="#contact" className="hover:text-primary transition-colors">Contact</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li className="hover:text-primary transition-colors">Renaud Olivier</li>
                <li className="hover:text-primary transition-colors">renaud_olivier@hotmail.fr</li>
                <li className="hover:text-primary transition-colors">06 65 65 56 05</li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-border text-center text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} Impact Mental. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}