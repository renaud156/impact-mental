import { memo } from 'react';

function LogoComponent({ className = "w-10 h-10" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#00d4ff" />
          <stop offset="100%" stopColor="#6366f1" />
        </linearGradient>
      </defs>

      {/* Forme principale - I */}
      <rect x="45" y="25" width="8" height="70" rx="4" fill="url(#logoGradient)"/>

      {/* Forme principale - M */}
      <path
        d="M 65 95 L 65 35 L 78 55 L 91 35 L 91 95"
        stroke="url(#logoGradient)"
        strokeWidth="8"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Points d'accent */}
      <circle cx="49" cy="25" r="4" fill="#00d4ff"/>
      <circle cx="49" cy="95" r="4" fill="#6366f1"/>
    </svg>
  );
}

export const Logo = memo(LogoComponent);
