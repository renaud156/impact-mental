import { memo } from 'react';
import * as Accordion from '@radix-ui/react-accordion';
import { ChevronDown } from 'lucide-react';

const faqData = [
  {
    question: "Qu'est-ce que la préparation mentale sportive ?",
    answer: "La préparation mentale sportive est un ensemble de techniques et d'outils permettant de développer vos capacités psychologiques pour optimiser vos performances. Elle travaille sur la concentration, la gestion du stress, la confiance en soi, la motivation et la résilience. C'est un complément essentiel à votre préparation physique et technique."
  },
  {
    question: "À qui s'adresse la préparation mentale ?",
    answer: "La préparation mentale s'adresse à tous les sportifs, quel que soit leur niveau : amateurs, compétiteurs, professionnels. Que vous pratiquiez un sport individuel (tennis, running, golf...) ou collectif (football, basket, rugby...), vous pouvez bénéficier d'un accompagnement mental pour progresser et atteindre vos objectifs."
  },
  {
    question: "Comment se déroule une séance ?",
    answer: "Une séance dure environ 1 heure et peut se faire en présentiel ou en visio. Nous commençons par échanger sur vos objectifs, vos difficultés et votre actualité sportive. Ensuite, nous travaillons sur des techniques spécifiques (visualisation, cohérence cardiaque, routines...) adaptées à vos besoins. Chaque séance inclut des exercices pratiques que vous pourrez réutiliser en autonomie."
  },
  {
    question: "Combien de séances sont nécessaires ?",
    answer: "Cela dépend de vos objectifs et de votre contexte. Certains sportifs viennent pour une préparation ponctuelle avant un événement important (1-3 séances), d'autres préfèrent un suivi régulier sur plusieurs mois. Le forfait mensuel (4 séances) est idéal pour un travail en profondeur et des résultats durables."
  },
  {
    question: "Quand commencer la préparation mentale ?",
    answer: "Il n'y a pas de mauvais moment ! Idéalement, commencez dès maintenant pour construire progressivement votre mental. Cependant, une préparation intensive peut aussi être mise en place avant une échéance importante (tournoi, championnat, compétition). Plus vous commencez tôt, plus vous aurez de temps pour intégrer les outils et voir les bénéfices."
  },
  {
    question: "Est-ce que la préparation mentale fonctionne vraiment ?",
    answer: "Oui ! Les études scientifiques et l'expérience des sportifs de haut niveau le prouvent. La préparation mentale est utilisée par la majorité des athlètes professionnels. Elle permet d'améliorer la concentration, la gestion du stress, la confiance et donc les performances. Les résultats dépendent de votre investissement et de la régularité de la pratique."
  },
  {
    question: "Puis-je pratiquer en autonomie après les séances ?",
    answer: "Absolument ! L'un des objectifs principaux est de vous rendre autonome. Chaque séance vous apporte des outils concrets (cohérence cardiaque, visualisation, routines...) que vous pourrez utiliser seul(e) au quotidien et en compétition. Je vous fournis également des supports et exercices pour continuer à pratiquer entre les séances."
  },
  {
    question: "Quelle est la différence entre un coach mental et un psychologue du sport ?",
    answer: "Le préparateur mental se concentre sur l'optimisation des performances et l'apprentissage d'outils pratiques pour le terrain. Le psychologue du sport peut également intervenir sur des problématiques plus profondes (anxiété, traumatismes, troubles). Mon approche est orientée performance, pratique et terrain, avec des outils concrets applicables immédiatement."
  }
];

function FAQComponent() {
  return (
    <Accordion.Root type="single" collapsible className="space-y-4">
      {faqData.map((item, index) => (
        <Accordion.Item
          key={index}
          value={`item-${index}`}
          className="bg-gradient-to-br from-card to-card/50 rounded-2xl border border-border overflow-hidden hover:border-primary/50 transition-all"
        >
          <Accordion.Header>
            <Accordion.Trigger className="group flex items-center justify-between w-full p-6 text-left hover:bg-primary/5 transition-colors">
              <span className="font-semibold text-lg pr-4">{item.question}</span>
              <ChevronDown className="w-5 h-5 text-primary flex-shrink-0 transition-transform duration-300 group-data-[state=open]:rotate-180" />
            </Accordion.Trigger>
          </Accordion.Header>
          <Accordion.Content className="data-[state=open]:animate-slideDown data-[state=closed]:animate-slideUp overflow-hidden">
            <div className="p-6 pt-0 text-muted-foreground leading-relaxed">
              {item.answer}
            </div>
          </Accordion.Content>
        </Accordion.Item>
      ))}
    </Accordion.Root>
  );
}

export const FAQ = memo(FAQComponent);
