import { useState, FormEvent } from 'react';
import { Check } from 'lucide-react';

interface Scores {
  [key: string]: number;
}

interface FormData {
  prenom: string;
  age: string;
  sport: string;
  niveau: string;
  objectif: string;
  force: string;
  frein: string;
  attentes: string;
  attentes_pm: string;
  situations: string[];
}

const messages: { [key: string]: { low: string; mid: string; high: string } } = {
  autonomie: {
    low: "Tu te sens contraint dans ta pratique. Travailler l'autonomie est une priorité.",
    mid: "Tu as une certaine liberté mais il y a encore des contraintes à lever.",
    high: "Tu te sens bien libre dans ta pratique sportive."
  },
  competence: {
    low: "Tu doutes de tes compétences actuelles. Reconstruire la confiance technique est essentiel.",
    mid: "Tu as des acquis solides mais la confiance en tes compétences peut encore progresser.",
    high: "Tu as une bonne conscience de tes compétences et de ta valeur sportive."
  },
  appartenance: {
    low: "Tu te sens isolé ou peu intégré. Le sentiment d'appartenance est un levier majeur de motivation.",
    mid: "Tu as des liens avec ton environnement sportif mais ils pourraient être renforcés.",
    high: "Tu te sens bien entouré et intégré dans ton environnement sportif."
  },
  plaisir: {
    low: "Le plaisir de jouer est fortement altéré. C'est souvent le premier signal d'alarme motivationnel.",
    mid: "Tu prends du plaisir mais il n'est pas constant. Identifier ce qui l'érode est important.",
    high: "Tu éprouves un plaisir fort dans ta pratique — c'est la meilleure fondation."
  },
  progres: {
    low: "Tu as le sentiment de stagner, ce qui peut décourager rapidement. Rendre les progrès visibles est prioritaire.",
    mid: "Tu progresses mais tu ne t'en rends pas suffisamment compte.",
    high: "Tu perçois tes progrès clairement — c'est excellent pour la motivation."
  },
  engagement: {
    low: "Tu dois te forcer à t'entraîner. C'est un signal fort : la motivation intrinsèque est à reconstruire.",
    mid: "Ton engagement est variable. Travailler le sens et les ingrédients motivationnels peut stabiliser ça.",
    high: "Tu as naturellement envie de t'entraîner — c'est un signe de motivation saine."
  },
  sens: {
    low: "Tu ne sais pas encore clairement pourquoi tu pratiques ce sport. Clarifier le 'pourquoi' est fondamental.",
    mid: "Tu as une idée de pourquoi tu pratiques mais ce sens n'est pas encore complètement ancré.",
    high: "Tu sais pourquoi tu pratiques et ce sport a un sens profond pour toi."
  }
};

export function BilanMental() {
  const [showResults, setShowResults] = useState(false);
  const [scores, setScores] = useState<Scores>({});
  const [formData, setFormData] = useState<FormData>({
    prenom: '',
    age: '',
    sport: '',
    niveau: '',
    objectif: '',
    force: '',
    frein: '',
    attentes: '',
    attentes_pm: '',
    situations: []
  });
  const [sendStatus, setSendStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [userEmail, setUserEmail] = useState('');

  const dimensions = [
    { id: 'autonomie', label: 'Autonomie', icon: '🎯', question: "Je me sens libre dans ma façon de pratiquer mon sport. Je ne suis pas constamment sous la contrainte.", minLabel: 'Pas du tout libre', maxLabel: 'Totalement libre' },
    { id: 'competence', label: 'Compétence', icon: '💪', question: "Je pense avoir acquis les compétences nécessaires pour pratiquer mon sport au niveau qui est le mien aujourd'hui.", minLabel: 'Pas du tout compétent', maxLabel: 'Très compétent' },
    { id: 'appartenance', label: 'Appartenance', icon: '🤝', question: "Je me sens proche de mon équipe, mon club ou mon entraîneur. Ils me connaissent vraiment en tant que personne.", minLabel: 'Très isolé', maxLabel: 'Comme une famille' },
    { id: 'plaisir', label: 'Plaisir', icon: '😄', question: "J'éprouve vraiment du plaisir quand je pratique mon sport, que ce soit à l'entraînement ou en compétition.", minLabel: 'Aucun plaisir', maxLabel: 'Énorme plaisir' },
    { id: 'progres', label: 'Progrès', icon: '📈', question: "J'ai le sentiment de progresser et de m'améliorer régulièrement dans mon sport en ce moment.", minLabel: 'Je stagne totalement', maxLabel: 'Je progresse énormément' },
    { id: 'engagement', label: 'Engagement', icon: '🔥', question: "Lorsque l'heure de l'entraînement arrive, j'ai naturellement envie d'y aller sans devoir me forcer.", minLabel: 'Je dois me forcer', maxLabel: "J'ai toujours envie" },
    { id: 'sens', label: 'Sens fondamental', icon: '🧭', question: "Je sais pourquoi je pratique ce sport et je peux expliquer en quoi c'est vraiment important pour moi dans ma vie.", minLabel: 'Je ne sais pas pourquoi', maxLabel: 'Je sais exactement pourquoi' }
  ];

  const handleScoreClick = (dimension: string, value: number) => {
    setScores({ ...scores, [dimension]: value });
  };

  const handleCheckboxChange = (value: string) => {
    const currentSituations = formData.situations;
    if (currentSituations.includes(value)) {
      setFormData({ ...formData, situations: currentSituations.filter(s => s !== value) });
    } else {
      setFormData({ ...formData, situations: [...currentSituations, value] });
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setShowResults(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const calculateTotal = () => {
    return Object.values(scores).reduce((sum, val) => sum + val, 0);
  };

  const getDescription = (total: number) => {
    if (total >= 56) return "Profil très motivé. Les fondations sont solides — le travail mental peut affiner les détails.";
    if (total >= 42) return "Profil motivé avec quelques zones de fragilité à consolider.";
    if (total >= 28) return "Profil avec des ressources réelles mais plusieurs leviers motivationnels à renforcer.";
    if (total >= 14) return "Profil fragile. Un travail ciblé sur les sentiments les plus bas est prioritaire.";
    return "Profil en difficulté motivationnelle. Un accompagnement personnalisé est fortement recommandé.";
  };

  const getProgressCount = () => {
    const scoresCount = Object.keys(scores).length;
    const fieldsCount = [formData.prenom, formData.sport].filter(f => f.trim()).length;
    return Math.min(scoresCount + fieldsCount, 14);
  };

  const restartForm = () => {
    setShowResults(false);
    setScores({});
    setFormData({
      prenom: '',
      age: '',
      sport: '',
      niveau: '',
      objectif: '',
      force: '',
      frein: '',
      attentes: '',
      attentes_pm: '',
      situations: []
    });
    setSendStatus('idle');
    setUserEmail('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const sendResults = async () => {
    if (!userEmail || !userEmail.includes('@')) {
      alert('Merci de saisir une adresse email valide');
      return;
    }

    setSendStatus('sending');

    const total = calculateTotal();
    const priorities = dimensions.filter(d => (scores[d.id] || 0) <= 4);

    // Formater les résultats pour l'email
    let resultText = `BILAN MENTAL - ${formData.prenom || 'Sportif'}\n\n`;
    resultText += `=== PROFIL ===\n`;
    resultText += `Prénom: ${formData.prenom}\n`;
    if (formData.age) resultText += `Âge: ${formData.age}\n`;
    if (formData.sport) resultText += `Sport: ${formData.sport}\n`;
    if (formData.niveau) resultText += `Niveau: ${formData.niveau}\n`;
    if (formData.objectif) resultText += `Objectif: ${formData.objectif}\n`;

    resultText += `\n=== SCORE GLOBAL ===\n`;
    resultText += `Score total: ${total}/70 points\n`;
    resultText += `Évaluation: ${getDescription(total)}\n`;

    resultText += `\n=== LES 7 DIMENSIONS ===\n`;
    dimensions.forEach(dim => {
      const val = scores[dim.id] || 0;
      const msg = val <= 4 ? messages[dim.id].low : val <= 7 ? messages[dim.id].mid : messages[dim.id].high;
      resultText += `${dim.icon} ${dim.label}: ${val}/10 - ${msg}\n`;
    });

    if (priorities.length > 0) {
      resultText += `\n=== AXES PRIORITAIRES ===\n`;
      priorities.forEach(p => {
        resultText += `⚠ ${p.label} (${scores[p.id]}/10)\n`;
      });
    }

    const stressVal = scores['stress'] || 0;
    const confianceVal = scores['confiance'] || 0;
    resultText += `\n=== STRESS & CONFIANCE ===\n`;
    resultText += `Stress avant compétition: ${stressVal}/10\n`;
    resultText += `Confiance avant compétition: ${confianceVal}/10\n`;

    if (formData.force || formData.frein || formData.situations.length > 0 || formData.attentes || formData.attentes_pm) {
      resultText += `\n=== RÉPONSES LIBRES ===\n`;
      if (formData.force) resultText += `Force mentale: ${formData.force}\n`;
      if (formData.frein) resultText += `Frein mental: ${formData.frein}\n`;
      if (formData.situations.length > 0) resultText += `Situations difficiles: ${formData.situations.join(', ')}\n`;
      if (formData.attentes) resultText += `Pression extérieure: ${formData.attentes}\n`;
      if (formData.attentes_pm) resultText += `Attentes prépa mentale: ${formData.attentes_pm}\n`;
    }

    const emailData = new FormData();
    emailData.append('access_key', 'YOUR_ACCESS_KEY_HERE'); // À remplacer par votre clé Web3Forms
    emailData.append('subject', `Bilan Mental - ${formData.prenom}`);
    emailData.append('from_name', 'Impact Mental - Questionnaire');
    emailData.append('email', userEmail);
    emailData.append('message', resultText);

    try {
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        body: emailData
      });

      const data = await response.json();

      if (data.success) {
        setSendStatus('success');
        setTimeout(() => setSendStatus('idle'), 5000);
      } else {
        setSendStatus('error');
        setTimeout(() => setSendStatus('idle'), 5000);
      }
    } catch (error) {
      setSendStatus('error');
      setTimeout(() => setSendStatus('idle'), 5000);
    }
  };

  if (showResults) {
    const total = calculateTotal();
    const priorities = dimensions.filter(d => (scores[d.id] || 0) <= 4);
    const stressVal = scores['stress'] || 0;
    const confianceVal = scores['confiance'] || 0;

    return (
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
            <span className="text-primary text-sm font-medium">Ton bilan personnalisé</span>
          </div>
          <h2 className="text-4xl sm:text-5xl mb-4 font-bold text-slate-900">
            Bilan de <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">{formData.prenom || 'Sportif'}</span>
          </h2>
          {formData.sport && (
            <p className="text-slate-600">
              {formData.sport}{formData.niveau && ` · ${formData.niveau}`}
            </p>
          )}
        </div>

        <div className="flex flex-col md:flex-row items-center justify-center gap-8 mb-12">
          <div className="w-32 h-32 border-4 border-primary rounded-full flex flex-col items-center justify-center bg-primary/10">
            <div className="text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">{total}</div>
            <div className="text-xs text-slate-600 uppercase tracking-wider">/ 70 pts</div>
          </div>
          <p className="max-w-md text-slate-900 text-center md:text-left">{getDescription(total)}</p>
        </div>

        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-6 text-primary">Tes 7 dimensions motivationnelles</h3>
          <div className="space-y-4">
            {dimensions.map(dim => {
              const val = scores[dim.id] || 0;
              const pct = val * 10;
              const color = val <= 3 ? '#E05050' : val <= 5 ? '#E8A020' : val <= 7 ? '#52B788' : '#2D6A4F';
              const msg = val <= 4 ? messages[dim.id].low : val <= 7 ? messages[dim.id].mid : messages[dim.id].high;

              return (
                <div key={dim.id} className="bg-white p-6 rounded-xl border-2 border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2 font-semibold text-slate-900">
                      <span>{dim.icon}</span>
                      <span>{dim.label}</span>
                    </div>
                    <div className="text-2xl font-bold" style={{ color }}>{val}/10</div>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden mb-3">
                    <div
                      className="h-full rounded-full transition-all duration-1000"
                      style={{ width: `${pct}%`, backgroundColor: color }}
                    />
                  </div>
                  <p className="text-sm text-slate-700 italic">{msg}</p>
                </div>
              );
            })}
          </div>
        </div>

        {priorities.length > 0 && (
          <div className="bg-red-50 border-2 border-red-300 rounded-xl p-6 mb-8">
            <h3 className="text-lg font-semibold text-red-700 mb-4">⚠ Axes prioritaires à travailler</h3>
            <ul className="space-y-2">
              {priorities.map(p => (
                <li key={p.id} className="flex items-center gap-3 text-slate-900">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span><strong>{p.icon} {p.label} ({scores[p.id]}/10)</strong> — {messages[p.id].low}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Stress & Confiance */}
        <div className="bg-white border-2 border-slate-200 rounded-xl p-6 mb-8">
          <h3 className="text-lg font-semibold text-primary mb-4">Stress & Confiance</h3>
          <div className="space-y-4 text-slate-900">
            <p>
              <strong className="text-slate-900">Stress avant compétition : {stressVal}/10</strong> —{' '}
              {stressVal >= 7
                ? "Niveau de stress élevé. Des routines de gestion du stress (respiration, visualisation, ancrage) sont à mettre en place en priorité."
                : stressVal >= 4
                ? "Stress modéré. Quelques outils de régulation suffisent à le contenir."
                : "Bon contrôle du stress. À maintenir par des routines préventives."}
            </p>
            <p>
              <strong className="text-slate-900">Confiance avant compétition : {confianceVal}/10</strong> —{' '}
              {confianceVal <= 4
                ? "Confiance fragile. Un travail sur l'inventaire des compétences et les micro-progrès est essentiel."
                : confianceVal <= 7
                ? "Confiance correcte mais perfectible. Les objectifs de processus aideront à la stabiliser."
                : "Bonne confiance en soi. Veiller à ne pas basculer dans la sur-confiance."}
            </p>
          </div>
        </div>

        {/* Réponses libres */}
        {(formData.force || formData.frein || formData.situations.length > 0 || formData.attentes || formData.attentes_pm) && (
          <div className="bg-white border-2 border-slate-200 rounded-xl p-6 mb-8">
            <h3 className="text-lg font-semibold text-primary mb-4">Analyse de tes réponses libres</h3>
            <div className="space-y-3 text-sm text-slate-900">
              {formData.force && <p><strong>Force mentale :</strong> "{formData.force}"</p>}
              {formData.frein && <p><strong>Frein principal :</strong> "{formData.frein}"</p>}
              {formData.situations.length > 0 && (
                <p><strong>Situations difficiles :</strong> {formData.situations.join(', ')}</p>
              )}
              {formData.attentes && (
                <p><strong>Pression extérieure :</strong> {
                  formData.attentes === 'oui' ? 'Oui, souvent ressentie' :
                  formData.attentes === 'parfois' ? 'Parfois ressentie' :
                  'Rarement ressentie'
                }</p>
              )}
              {formData.attentes_pm && <p><strong>Attentes de la prépa mentale :</strong> "{formData.attentes_pm}"</p>}
            </div>
          </div>
        )}

        <div className="bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/30 rounded-xl p-8 text-center mb-8">
          <h3 className="text-xl font-bold text-primary mb-4">💡 Recommandation</h3>
          <p className="text-slate-900">
            {priorities.length === 0
              ? `${formData.prenom}, ton profil motivationnel est solide. Un travail de préparation mentale peut maintenant se concentrer sur les routines de performance, la gestion du stress compétitif et l'imagerie mentale pour aller encore plus loin.`
              : priorities.length <= 2
              ? `${formData.prenom}, ton profil présente ${priorities.length === 1 ? 'un axe prioritaire' : 'deux axes prioritaires'} à travailler : ${priorities.map(p => p.label).join(' et ')}. Un programme court et ciblé sur ces dimensions peut transformer rapidement ta pratique.`
              : `${formData.prenom}, plusieurs dimensions motivationnelles sont en difficulté. Un accompagnement structuré sur 8 à 12 semaines, travaillant progressivement chaque levier, est la voie recommandée.`}
          </p>
        </div>

        {/* Formulaire d'envoi des résultats */}
        <div className="bg-white border-2 border-slate-200 rounded-xl p-8 mb-8">
          <h3 className="text-xl font-bold text-slate-900 mb-4 text-center">📧 Recevoir mes résultats et réserver une séance</h3>
          <p className="text-sm text-slate-600 mb-6 text-center">
            Entrez votre email pour recevoir votre bilan complet et discuter de votre accompagnement personnalisé.
          </p>

          <div className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                value={userEmail}
                onChange={e => setUserEmail(e.target.value)}
                placeholder="votre@email.fr"
                className="flex-1 px-4 py-3 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-slate-900"
                disabled={sendStatus === 'sending'}
              />
              <button
                onClick={sendResults}
                disabled={sendStatus === 'sending' || !userEmail}
                className="bg-gradient-to-r from-primary to-accent text-white px-8 py-3 rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all font-medium disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
              >
                {sendStatus === 'sending' ? 'Envoi...' : 'Envoyer mes résultats'}
              </button>
            </div>

            {sendStatus === 'success' && (
              <div className="mt-4 p-4 bg-green-50 border-2 border-green-300 rounded-xl text-green-700 text-sm text-center">
                ✓ Résultats envoyés avec succès ! Vous allez recevoir un email et je vous recontacterai rapidement.
              </div>
            )}

            {sendStatus === 'error' && (
              <div className="mt-4 p-4 bg-red-50 border-2 border-red-300 rounded-xl text-red-700 text-sm text-center">
                ✗ Une erreur est survenue. Veuillez réessayer ou me contacter directement.
              </div>
            )}

            <p className="text-xs text-slate-500 mt-4 text-center italic">
              En envoyant vos résultats, vous acceptez d'être recontacté pour un accompagnement personnalisé.
            </p>
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={restartForm}
            className="bg-white border-2 border-primary/30 text-slate-900 px-8 py-3 rounded-xl hover:border-primary hover:bg-primary/5 transition-all font-medium"
          >
            ↩ Refaire le questionnaire
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <div className="inline-block mb-4 px-4 py-1 bg-primary/10 border border-primary/20 rounded-full">
          <span className="text-primary text-sm font-medium">Préparation Mentale du Sportif</span>
        </div>
        <h1 className="text-5xl sm:text-6xl mb-4 font-bold">
          <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Bilan Mental</span>
        </h1>
        <p className="text-slate-600">
          Réponds honnêtement à chaque question.<br />
          Pas de bonne ou mauvaise réponse — seulement <em>ta</em> réalité aujourd'hui.
        </p>
      </div>

      {/* Progress */}
      <div className="bg-white/50 border-2 border-slate-200 rounded-xl p-4 mb-8 sticky top-20 z-10 backdrop-blur-sm">
        <div className="flex justify-between text-xs text-slate-600 uppercase tracking-wider mb-2">
          <span>Progression</span>
          <span>{getProgressCount()} / 14 questions</span>
        </div>
        <div className="h-1 bg-slate-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-accent rounded-full transition-all duration-300"
            style={{ width: `${Math.min(100, (getProgressCount() / 14) * 100)}%` }}
          />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Infos */}
        <div>
          <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
            Ton profil
            <div className="flex-1 h-px bg-primary/30" />
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                Prénom
              </label>
              <input
                type="text"
                value={formData.prenom}
                onChange={e => setFormData({ ...formData, prenom: e.target.value })}
                placeholder="Ton prénom"
                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-slate-900"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                Âge
              </label>
              <input
                type="number"
                value={formData.age}
                onChange={e => setFormData({ ...formData, age: e.target.value })}
                placeholder="Ton âge"
                min="8"
                max="99"
                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                Sport pratiqué
              </label>
              <input
                type="text"
                value={formData.sport}
                onChange={e => setFormData({ ...formData, sport: e.target.value })}
                placeholder="Ex : Football, Tennis..."
                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                Niveau
              </label>
              <select
                value={formData.niveau}
                onChange={e => setFormData({ ...formData, niveau: e.target.value })}
                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-slate-900"
              >
                <option value="">-- Sélectionner --</option>
                <option>Loisir / Débutant</option>
                <option>Club amateur</option>
                <option>Compétition régionale</option>
                <option>Compétition nationale</option>
                <option>Semi-professionnel</option>
                <option>Professionnel</option>
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                Ton objectif principal en ce moment
              </label>
              <input
                type="text"
                value={formData.objectif}
                onChange={e => setFormData({ ...formData, objectif: e.target.value })}
                placeholder="Ex : Être sélectionné, progresser techniquement, gérer mon stress..."
                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-slate-900"
              />
            </div>
          </div>
        </div>

        {/* Les 7 dimensions */}
        <div>
          <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
            Les 7 dimensions de ta motivation
            <div className="flex-1 h-px bg-primary/30" />
          </h3>
          <div className="bg-primary/5 border-2 border-primary/20 rounded-xl p-4 mb-6">
            <p className="text-sm text-slate-700">
              Pour chaque affirmation, choisis la note de <strong>0 à 10</strong> qui correspond le mieux à ce que tu ressens <strong>aujourd'hui</strong>.
              <br />0 = pas du tout · 10 = complètement
            </p>
          </div>

          <div className="space-y-6">
            {dimensions.map((dim, idx) => (
              <div key={dim.id} className="bg-white border-2 border-slate-200 rounded-xl p-6 shadow-sm">
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-12 h-12 bg-primary/10 border-2 border-primary/30 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
                    {dim.icon}
                  </div>
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wider text-primary mb-1">
                      {idx + 1} · {dim.label}
                    </div>
                    <div className="text-sm text-slate-900">{dim.question}</div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs text-slate-600 mb-2">
                    <span>{dim.minLabel}</span>
                    <span>{dim.maxLabel}</span>
                  </div>

                  {/* Mobile: Slider */}
                  <div className="md:hidden">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={scores[dim.id] || 0}
                      onChange={(e) => handleScoreClick(dim.id, parseInt(e.target.value))}
                      className="w-full h-3 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary"
                      style={{
                        background: `linear-gradient(to right, #00d4ff ${(scores[dim.id] || 0) * 10}%, #e2e8f0 ${(scores[dim.id] || 0) * 10}%)`
                      }}
                    />
                    <div className="text-center mt-2">
                      <span className="inline-block bg-primary text-white px-6 py-2 rounded-full text-lg font-bold">
                        {scores[dim.id] !== undefined ? scores[dim.id] : '0'}
                      </span>
                    </div>
                  </div>

                  {/* Desktop: Boutons */}
                  <div className="hidden md:flex gap-1">
                    {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(val => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => handleScoreClick(dim.id, val)}
                        className={`flex-1 h-10 rounded-lg border-2 transition-all font-bold text-sm ${
                          scores[dim.id] === val
                            ? val >= 7
                              ? 'bg-gradient-to-br from-primary to-accent border-primary text-white shadow-lg'
                              : val <= 3
                              ? 'bg-red-500 border-red-400 text-white shadow-lg'
                              : 'bg-primary border-primary text-white shadow-lg'
                            : 'bg-white border-slate-300 text-slate-700 hover:border-primary hover:bg-primary/10'
                        }`}
                      >
                        {val}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pression & stress */}
        <div>
          <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
            Pression & gestion émotionnelle
            <div className="flex-1 h-px bg-primary/30" />
          </h3>

          <div className="space-y-6">
            <div className="bg-white border-2 border-slate-200 rounded-xl p-6 shadow-sm">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 bg-primary/10 border-2 border-primary/30 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
                  😰
                </div>
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-primary mb-1">
                    8 · Gestion du stress
                  </div>
                  <div className="text-sm text-slate-900">Avant une compétition ou une évaluation importante, je ressens un stress désagréable qui nuit à mes performances.</div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs text-slate-600 mb-2">
                  <span>Jamais</span>
                  <span>Très souvent</span>
                </div>

                {/* Mobile: Slider */}
                <div className="md:hidden">
                  <input
                    type="range"
                    min="0"
                    max="10"
                    value={scores.stress || 0}
                    onChange={(e) => handleScoreClick('stress', parseInt(e.target.value))}
                    className="w-full h-3 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary"
                    style={{
                      background: `linear-gradient(to right, #00d4ff ${(scores.stress || 0) * 10}%, #e2e8f0 ${(scores.stress || 0) * 10}%)`
                    }}
                  />
                  <div className="text-center mt-2">
                    <span className="inline-block bg-primary text-white px-6 py-2 rounded-full text-lg font-bold">
                      {scores.stress !== undefined ? scores.stress : '0'}
                    </span>
                  </div>
                </div>

                {/* Desktop: Boutons */}
                <div className="hidden md:flex gap-1">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(val => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => handleScoreClick('stress', val)}
                      className={`flex-1 h-10 rounded-lg border-2 transition-all font-bold text-sm ${
                        scores.stress === val
                          ? 'bg-primary border-primary text-white shadow-lg'
                          : 'bg-white border-slate-300 text-slate-700 hover:border-primary hover:bg-primary/10'
                      }`}
                    >
                      {val}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white border-2 border-slate-200 rounded-xl p-6 shadow-sm">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 bg-primary/10 border-2 border-primary/30 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
                  🦁
                </div>
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-primary mb-1">
                    9 · Confiance en soi
                  </div>
                  <div className="text-sm text-slate-900">Juste avant de commencer à jouer, je me sens confiant dans mes capacités à bien performer.</div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs text-slate-600 mb-2">
                  <span>Pas du tout confiant</span>
                  <span>Pleinement confiant</span>
                </div>

                {/* Mobile: Slider */}
                <div className="md:hidden">
                  <input
                    type="range"
                    min="0"
                    max="10"
                    value={scores.confiance || 0}
                    onChange={(e) => handleScoreClick('confiance', parseInt(e.target.value))}
                    className="w-full h-3 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary"
                    style={{
                      background: `linear-gradient(to right, #00d4ff ${(scores.confiance || 0) * 10}%, #e2e8f0 ${(scores.confiance || 0) * 10}%)`
                    }}
                  />
                  <div className="text-center mt-2">
                    <span className="inline-block bg-primary text-white px-6 py-2 rounded-full text-lg font-bold">
                      {scores.confiance !== undefined ? scores.confiance : '0'}
                    </span>
                  </div>
                </div>

                {/* Desktop: Boutons */}
                <div className="hidden md:flex gap-1">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(val => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => handleScoreClick('confiance', val)}
                      className={`flex-1 h-10 rounded-lg border-2 transition-all font-bold text-sm ${
                        scores.confiance === val
                          ? 'bg-primary border-primary text-white shadow-lg'
                          : 'bg-white border-slate-300 text-slate-700 hover:border-primary hover:bg-primary/10'
                      }`}
                    >
                      {val}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Questions ouvertes */}
        <div>
          <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
            Questions ouvertes
            <div className="flex-1 h-px bg-primary/30" />
          </h3>

          <div className="space-y-6">
            <div className="bg-white border-l-4 border-l-primary border-2 border-slate-200 rounded-xl p-6">
              <div className="text-xs font-bold uppercase tracking-wider text-primary mb-2">
                10 · Ta plus grande force mentale
              </div>
              <div className="text-sm text-slate-600 mb-3">
                Selon toi, quelle est ta plus grande qualité mentale en tant que sportif ?
              </div>
              <textarea
                value={formData.force}
                onChange={e => setFormData({ ...formData, force: e.target.value })}
                placeholder="Ex : Je ne lâche jamais, je reste calme sous pression, je rebondis vite après une erreur..."
                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none min-h-20 text-slate-900"
              />
            </div>

            <div className="bg-white border-l-4 border-l-primary border-2 border-slate-200 rounded-xl p-6">
              <div className="text-xs font-bold uppercase tracking-wider text-primary mb-2">
                11 · Ton plus grand frein mental
              </div>
              <div className="text-sm text-slate-600 mb-3">
                Qu'est-ce qui te bloque ou te freine le plus mentalement aujourd'hui ?
              </div>
              <textarea
                value={formData.frein}
                onChange={e => setFormData({ ...formData, frein: e.target.value })}
                placeholder="Ex : La peur de décevoir, le regard des autres, les erreurs qui m'obsèdent..."
                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none min-h-20 text-slate-900"
              />
            </div>

            <div className="bg-white border-l-4 border-l-primary border-2 border-slate-200 rounded-xl p-6">
              <div className="text-xs font-bold uppercase tracking-wider text-primary mb-2">
                12 · Situations difficiles
              </div>
              <div className="text-sm text-slate-600 mb-3">
                Dans quelles situations te sens-tu le plus sous pression ? (plusieurs réponses possibles)
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                {[
                  { value: 'selection', label: 'Lors d\'une sélection / détection' },
                  { value: 'match_important', label: 'Lors d\'un match important' },
                  { value: 'apres_erreur', label: 'Après une erreur' },
                  { value: 'regard_coach', label: 'Sous le regard de l\'entraîneur' },
                  { value: 'regard_parents', label: 'Sous le regard des parents' },
                  { value: 'comparaison', label: 'En me comparant aux autres' },
                  { value: 'mauvaise_forme', label: 'Quand je suis en mauvaise forme' },
                  { value: 'remplacant', label: 'Quand je suis sur le banc / en retrait' }
                ].map(situation => (
                  <label
                    key={situation.value}
                    className={`flex items-center gap-3 p-3 border-2 rounded-lg cursor-pointer transition-all ${
                      formData.situations.includes(situation.value)
                        ? 'bg-primary/10 border-primary'
                        : 'bg-white border-slate-200 hover:border-primary/50'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={formData.situations.includes(situation.value)}
                      onChange={() => handleCheckboxChange(situation.value)}
                      className="hidden"
                    />
                    <div className={`w-5 h-5 border-2 rounded flex items-center justify-center ${
                      formData.situations.includes(situation.value)
                        ? 'bg-primary border-primary'
                        : 'border-slate-400'
                    }`}>
                      {formData.situations.includes(situation.value) && (
                        <Check className="w-3 h-3 text-white" />
                      )}
                    </div>
                    <span className="text-sm text-slate-900">{situation.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="bg-white border-l-4 border-l-primary border-2 border-slate-200 rounded-xl p-6">
              <div className="text-xs font-bold uppercase tracking-wider text-primary mb-2">
                13 · Attentes extérieures
              </div>
              <div className="text-sm text-slate-600 mb-3">
                As-tu l'impression que les adultes autour de toi (parents, entraîneur) attendent des résultats précis de ta part ?
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                {[
                  { value: 'oui', label: 'Oui, souvent' },
                  { value: 'parfois', label: 'Parfois' },
                  { value: 'non', label: 'Non, rarement' }
                ].map(option => (
                  <label
                    key={option.value}
                    className={`flex-1 flex items-center gap-3 p-3 border-2 rounded-lg cursor-pointer transition-all ${
                      formData.attentes === option.value
                        ? 'bg-primary/10 border-primary'
                        : 'bg-white border-slate-200 hover:border-primary/50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="attentes"
                      value={option.value}
                      checked={formData.attentes === option.value}
                      onChange={e => setFormData({ ...formData, attentes: e.target.value })}
                      className="hidden"
                    />
                    <div className={`w-5 h-5 border-2 rounded-full flex items-center justify-center ${
                      formData.attentes === option.value
                        ? 'border-primary'
                        : 'border-slate-400'
                    }`}>
                      {formData.attentes === option.value && (
                        <div className="w-3 h-3 bg-primary rounded-full" />
                      )}
                    </div>
                    <span className="text-sm text-slate-900">{option.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="bg-white border-l-4 border-l-primary border-2 border-slate-200 rounded-xl p-6">
              <div className="text-xs font-bold uppercase tracking-wider text-primary mb-2">
                14 · Ce que tu attends de la préparation mentale
              </div>
              <div className="text-sm text-slate-600 mb-3">
                Qu'est-ce que tu espères améliorer grâce à un suivi en préparation mentale ?
              </div>
              <textarea
                value={formData.attentes_pm}
                onChange={e => setFormData({ ...formData, attentes_pm: e.target.value })}
                placeholder="Ex : Mieux gérer le stress, avoir plus confiance en moi, mieux rebondir après les erreurs..."
                className="w-full px-4 py-3 bg-white border-2 border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none min-h-20 text-slate-900"
              />
            </div>
          </div>
        </div>

        {/* Submit */}
        <div className="text-center pt-8">
          <button
            type="submit"
            className="bg-gradient-to-r from-primary to-accent text-white px-12 py-4 rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all text-lg font-bold uppercase tracking-wider"
          >
            Voir mon bilan ⚡
          </button>
          <p className="text-xs text-slate-600 mt-4 italic">
            Tes réponses sont confidentielles et utilisées uniquement pour établir ton bilan personnalisé.
          </p>
        </div>
      </form>
    </div>
  );
}
