interface CtaBannerProps {
  title: string;
  description: string;
  primaryText: string;
  primaryHref: string;
  secondaryText?: string;
  secondaryHref?: string;
}

export function CtaBanner({
  title,
  description,
  primaryText,
  primaryHref,
  secondaryText,
  secondaryHref
}: CtaBannerProps) {
  return (
    <section className="relative py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/5 via-accent/5 to-primary/5">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl sm:text-4xl font-bold mb-4">
          <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            {title}
          </span>
        </h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          {description}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href={primaryHref}
            className="inline-flex items-center justify-center bg-primary text-primary-foreground px-8 py-3 rounded-lg hover:opacity-90 transition-opacity font-medium text-lg"
          >
            {primaryText}
          </a>
          {secondaryText && secondaryHref && (
            <a
              href={secondaryHref}
              className="inline-flex items-center justify-center bg-secondary text-secondary-foreground px-8 py-3 rounded-lg hover:opacity-90 transition-opacity font-medium text-lg"
            >
              {secondaryText}
            </a>
          )}
        </div>
      </div>
    </section>
  );
}
