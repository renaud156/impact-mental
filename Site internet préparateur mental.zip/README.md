
  # Site internet préparateur mental

  This is a code bundle for Site internet préparateur mental. The original project is available at https://www.figma.com/design/kyyJ3kbEipv6KRiOenzdx9/Site-internet-pr%C3%A9parateur-mental.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  